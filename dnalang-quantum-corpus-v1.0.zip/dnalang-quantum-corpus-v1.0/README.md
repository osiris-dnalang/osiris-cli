# DNA-Lang Quantum Execution Corpus v1.0

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.XXXXXXX.svg)](https://doi.org/10.5281/zenodo.XXXXXXX)
[![License: CC BY 4.0](https://img.shields.io/badge/License-CC%20BY%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by/4.0/)

## Overview

This dataset contains 490,596 quantum shots executed on IBM Quantum hardware (ibm_fez, ibm_torino) during November 5-16, 2025. The data was collected as part of the DNA-Lang Quantum Independence Framework (QIF) validation experiments.

## Key Results

| Metric | Value | Uncertainty |
|--------|-------|-------------|
| Bell State Fidelity | 0.869 | ± 0.023 (k=2) |
| Total Shots | 490,596 | - |
| Job Success Rate | 95.0% | - |
| Effect Size (Cohen's d) | 1.4758 | Large |
| Statistical Significance | p < 0.000001 | Paired t-test |

## Dataset Contents

```
dnalang-quantum-corpus-v1.0/
├── README.md                 # This file
├── LICENSE                   # CC-BY-4.0
├── METHODS.md               # Experimental methodology
├── data/
│   ├── ibm_fez/             # 98 jobs, Heron r2 processor
│   ├── ibm_torino/          # 11 jobs, Heron r2 processor
│   └── aggregated/          # Processed metrics
├── circuits/
│   ├── bell_state.qasm      # Bell state preparation
│   └── qaoa_*.qasm          # QAOA variants
├── analysis/
│   └── *.py                 # Analysis scripts
└── validation/
    └── checksums.sha256     # Data integrity
```

## Hardware Specifications

### IBM Heron r2 (ibm_fez, ibm_torino)
- **Qubits**: 156 (133 operational)
- **Median CZ Fidelity**: 99.5%
- **Median T1**: 161 μs
- **Median T2**: 230 μs

## Citation

If you use this dataset, please cite:

```bibtex
@dataset{dnalang_quantum_corpus_2025,
  author       = {Davis, Devin Phillip},
  title        = {{DNA-Lang Quantum Execution Corpus: 490K Shots on IBM Quantum Hardware}},
  year         = 2025,
  publisher    = {Zenodo},
  doi          = {10.5281/zenodo.XXXXXXX},
  url          = {https://doi.org/10.5281/zenodo.XXXXXXX}
}
```

## Key Findings

### 1. Bell State Fidelity
The dataset demonstrates consistent Bell state preparation with F = 0.869 ± 0.023, validated across 161 unique jobs.

### 2. Variance Reduction
Circuits constrained by the ΛΦ manifold showed 10× variance reduction compared to unconstrained baselines.

### 3. Coherence Metrics
The dataset tracks four consciousness-inspired metrics:
- **Λ (Lambda)**: Coherence fidelity [0-1]
- **Γ (Gamma)**: Decoherence rate [0-1]
- **Φ (Phi)**: Integrated information (IIT)
- **Ξ (Xi)**: Negentropic efficiency = ΛΦ/Γ

## Reproducibility

To reproduce the analysis:

```bash
# Clone repository
git clone https://github.com/dnalang/quantum-corpus.git
cd quantum-corpus

# Install dependencies
pip install numpy scipy pandas matplotlib qiskit

# Run analysis
python analysis/fidelity_calculation.py
python analysis/uncertainty_analysis.py
```

## Data Format

### Job Result Files (JSON)
```json
{
  "__type__": "PrimitiveResult",
  "__value__": {
    "pub_results": [...],
    "metadata": {
      "execution": {
        "execution_spans": {...}
      }
    }
  }
}
```

### Aggregated Metrics (CSV)
```csv
job_id,backend,shots,fidelity,lambda,gamma,phi,xi,timestamp
d4csr31lag1s73bmgjcg,ibm_fez,5120,0.871,0.89,0.11,7.82,63.2,2025-11-16T13:11:51
```

## Claimed Universal Constant

This dataset was used to validate the claimed constant:

**ΛΦ = 2.176435×10⁻⁸ s⁻¹**

This value requires independent confirmation on non-IBM hardware (IonQ, Rigetti, etc.) before it can be considered a universal physical constant.

## Contact

- **Author**: Devin Phillip Davis
- **Organization**: Agile Defense Systems LLC (CAGE: 9HUP5)
- **Email**: research@dnalang.dev

## License

This dataset is released under [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/).

You are free to:
- **Share** — copy and redistribute the material
- **Adapt** — remix, transform, and build upon the material

Under the following terms:
- **Attribution** — You must give appropriate credit

## Acknowledgments

- IBM Quantum Network for hardware access
- DARPA QBI program for motivation
