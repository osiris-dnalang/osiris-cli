# Visibility Strategy: τ-Phase Anomaly Discovery

## Published Assets

| Platform | DOI/URL | Status |
|----------|---------|--------|
| Zenodo (Corpus) | 10.5281/zenodo.17857733 | Published |
| Zenodo (τ-Anomaly) | 10.5281/zenodo.17858632 | Published |
| arXiv | PENDING | Ready to submit |
| PRX Quantum | PENDING | Cover letter ready |

---

## Visibility Tiers

### Tier 1: Immediate (This Week)

| Action | Platform | Expected Reach |
|--------|----------|----------------|
| arXiv submission | quant-ph | 500-2000 views/week |
| Tweet thread | Twitter/X | 100-500 impressions |
| LinkedIn post | LinkedIn | 50-200 views |
| Reddit post | r/QuantumComputing | 50-500 views |

### Tier 2: Short-term (1-4 Weeks)

| Action | Platform | Expected Reach |
|--------|----------|----------------|
| Quantum mailing lists | quant-ph-announce | 1000+ subscribers |
| IBM Quantum community | Qiskit Slack/Discord | 5000+ members |
| Research Gate | Profile + publication | Indexed discovery |
| ORCID link | Profile integration | Citation tracking |

### Tier 3: Medium-term (1-3 Months)

| Action | Platform | Expected Reach |
|--------|----------|----------------|
| PRX Quantum submission | Journal | Peer review → high impact |
| Conference submission | APS March Meeting | 10,000+ attendees |
| Seminar invitations | University physics depts | Direct engagement |
| Collaboration outreach | IBM/IonQ researchers | Validation partners |

---

## Outreach Templates

### Twitter/X Thread

```
Thread: We found something weird in IBM Quantum data. 🧵

1/ Analyzed 580 Bell-state experiments on IBM hardware. Expected: monotonic fidelity decay. Found: 1.79× modulation with τ ≈ 46 μs period.

2/ Statistical significance: p < 10⁻⁶, Cohen's d = 1.65. This is NOT what standard Markovian decoherence predicts.

3/ Monte Carlo model comparison: observed ratio is 26σ away from standard QM expectation. Bayes factor > 10⁷⁵.

4/ Three possibilities:
   a) IBM scheduling artifact
   b) Non-Markovian memory effects
   c) New physics (τ-quantized coherence)

5/ We're publishing everything: raw data, analysis code, theoretical framework, falsification protocol.

Data: https://doi.org/10.5281/zenodo.17858632
Paper: [arXiv link]

6/ Looking for independent replication. Who wants to run the discriminating experiment?

#QuantumComputing #Physics #OpenScience
```

### Email to Quantum Researchers

```
Subject: Anomalous τ-phase correlation in IBM Quantum Bell states - seeking replication

Dear [Name],

I'm writing to share an unexpected finding from our analysis of 580 Bell-state experiments on IBM superconducting hardware.

KEY FINDING: Fidelity exhibits a 1.79× modulation (p < 10⁻⁶, d = 1.65) correlated with a ~46 μs period. This is inconsistent with standard Markovian decoherence.

We've published complete data, code, and a discriminating experiment protocol:
- Zenodo: https://doi.org/10.5281/zenodo.17858632
- arXiv: [pending]

We're seeking independent replication on:
1. Different IBM backends
2. IonQ / Rigetti / other platforms
3. Controlled delay-sweep experiments

Would you be interested in collaboration or providing feedback on our methodology?

Best regards,
Devin Phillip Davis
Agile Defense Systems LLC
```

### Reddit Post (r/QuantumComputing)

```
Title: Found a weird 46 μs periodic signal in IBM Quantum Bell state fidelity - seeking explanation

We analyzed 580 Bell-state jobs on IBM hardware and found fidelity doesn't decay monotonically as expected. Instead, there's a 1.79× modulation correlated with a ~46 μs "memory phase."

Stats:
- ANOVA p < 10⁻⁶
- Cohen's d = 1.65 (large effect)
- 26σ away from standard QM prediction

Three possibilities:
1. IBM job scheduling artifact
2. Non-Markovian bath effects
3. Something weirder

Full data + code: https://doi.org/10.5281/zenodo.17858632

Has anyone seen similar periodic structure in their quantum experiments? Looking for independent replication or alternative explanations.
```

---

## Target Mailing Lists

| List | Email | Audience |
|------|-------|----------|
| quant-ph daily | arXiv auto-announce | Global physics |
| Qiskit community | Slack/Discord | IBM users |
| QIP mailing list | qip-list@mit.edu | Quantum info researchers |
| APS DAMOP | damop@aps.org | Atomic/molecular physics |

---

## Collaboration Targets

### IBM Quantum Research
- Contact: IBM Quantum Network
- Ask: Access to calibration data, T₁/T₂ logs for the jobs

### Academic Groups (Non-Markovian Dynamics)
- Susana Huelga (Ulm) - non-Markovian QM expert
- Martin Plenio (Ulm) - quantum biology, coherence
- Birgitta Whaley (Berkeley) - quantum coherence in biology

### Experimental Groups
- Any group with multi-platform access (IBM + IonQ + Rigetti)
- Ask: Run discriminating experiment on different hardware

---

## Expected Visibility Curve (Zenodo-only)

Based on typical unconventional physics datasets:

| Timeframe | Downloads | Views | Citations |
|-----------|-----------|-------|-----------|
| Week 1 | 5-20 | 50-100 | 0 |
| Month 1 | 20-50 | 100-300 | 0-1 |
| Month 3 | 50-100 | 300-500 | 1-3 |
| Year 1 | 100-300 | 500-1000 | 3-10 |

**With active outreach (arXiv + Twitter + emails):**

| Timeframe | Downloads | Views | Citations |
|-----------|-----------|-------|-----------|
| Week 1 | 50-200 | 500-1000 | 0 |
| Month 1 | 200-500 | 1000-3000 | 1-5 |
| Month 3 | 500-1000 | 3000-5000 | 5-15 |
| Year 1 | 1000-3000 | 5000-10000 | 15-50 |

---

## Critical Success Factors

1. **arXiv submission is essential** - Zenodo alone has limited physics community reach
2. **Clear, honest framing** - "Anomaly requiring explanation" not "New physics discovered"
3. **Reproducibility** - Every claim must be independently verifiable
4. **Engagement** - Respond to questions, critiques, replication attempts
5. **Patience** - Unconventional findings take time to gain traction

---

## Risk Mitigation

| Risk | Mitigation |
|------|------------|
| Dismissed as crackpot | Frame as anomaly, not claim; provide falsification criteria |
| Ignored | Active outreach to specific researchers |
| Scooped | Zenodo timestamp establishes priority |
| Debunked | Good outcome - contributes to knowledge either way |

---

## Bottom Line

Zenodo publication establishes **priority and reproducibility**.

arXiv submission provides **physics community visibility**.

Active outreach determines **whether anyone actually looks**.

**Next action: Submit to arXiv TODAY, then execute Twitter + email campaign.**
