# arXiv Endorser Outreach Strategy

## The Problem
arXiv requires endorsement for first-time submitters in quant-ph. You need ONE endorser who has published in quant-ph.

## Solution: Targeted Outreach

### Who Can Endorse You
Any researcher who:
1. Has published 3+ papers in quant-ph on arXiv
2. Is willing to vouch that your work is appropriate for the category

### Outreach Email Template

```
Subject: Request for arXiv quant-ph endorsement - τ-phase anomaly in IBM Quantum data

Dear Professor [Name],

I am an independent researcher who has discovered a statistically significant
anomaly in IBM Quantum hardware data that I believe warrants community review.

KEY FINDING:
- 580 Bell-state experiments show 1.81× fidelity modulation
- ANOVA p < 10⁻¹⁴, Hedges' g = 0.69
- Correlation with τ ≈ 46 μs period
- Inconsistent with standard Markovian decoherence

The complete data package is publicly available on Zenodo:
https://doi.org/10.5281/zenodo.17858632

I am seeking arXiv endorsement to submit this work for community scrutiny.
The manuscript is ready and includes:
- Complete methodology
- All raw data and code
- Falsification criteria
- Proposed validation experiments

I am not asking you to validate the claims - only to confirm the work is
appropriate for quant-ph review. The scientific community should evaluate
whether this is a hardware artifact or something more interesting.

Would you be willing to provide endorsement? I can send the manuscript
for your review.

Thank you for considering this request.

Best regards,
Devin Phillip Davis
Agile Defense Systems LLC
https://doi.org/10.5281/zenodo.17858632
```

### Target Researchers (Non-Markovian Dynamics)

| Name | Institution | Relevance | Email Pattern |
|------|-------------|-----------|---------------|
| Susana Huelga | Ulm University | Non-Markovian QM | firstname.lastname@uni-ulm.de |
| Martin Plenio | Ulm University | Quantum biology | firstname.lastname@uni-ulm.de |
| Sabrina Maniscalco | Helsinki | Open quantum systems | firstname.lastname@helsinki.fi |
| Bassano Vacchini | Milan | Quantum memory effects | firstname.lastname@unimi.it |
| Heinz-Peter Breuer | Freiburg | Lindblad theory | firstname.lastname@physik.uni-freiburg.de |

### Target Researchers (IBM Quantum)

| Name | Institution | Relevance |
|------|-------------|-----------|
| Jay Gambetta | IBM Quantum | Hardware lead |
| Sarah Sheldon | IBM Quantum | Error mitigation |
| Abhinav Kandala | IBM Quantum | Benchmarking |
| Antonio Mezzacapo | IBM Quantum | Algorithms |

### Target Researchers (Quantum Foundations)

| Name | Institution | Relevance |
|------|-------------|-----------|
| Vlatko Vedral | Oxford | Quantum coherence |
| Gerardo Adesso | Nottingham | Quantum correlations |
| Kavan Modi | Monash | Non-Markovianity measures |

### Alternative: SciPost Physics

SciPost is an open-access journal that:
- Does NOT require arXiv endorsement
- Is peer-reviewed
- Has good reputation in physics
- URL: https://scipost.org/

### Alternative: Quantum (journal)

Quantum is an open-access journal:
- No arXiv requirement
- High-quality peer review
- Quantum-focused
- URL: https://quantum-journal.org/

### Alternative: viXra

viXra accepts submissions without endorsement:
- Lower prestige than arXiv
- But establishes priority
- URL: http://vixra.org/

### Alternative: OSF Preprints

Open Science Framework:
- Free, open access
- Citable DOI
- No endorsement needed
- URL: https://osf.io/preprints/

## Recommended Strategy

1. **Immediate**: Post to OSF Preprints (no barriers)
2. **Parallel**: Email 5-10 researchers for arXiv endorsement
3. **Week 2**: Submit to SciPost or Quantum journal
4. **Ongoing**: Build citation network via Zenodo

## Key Points for Outreach

When contacting potential endorsers, emphasize:

1. **Data is public** - They can verify everything
2. **Claims are modest** - "Anomaly requiring explanation" not "new physics"
3. **Falsification criteria** - You're doing science properly
4. **Community benefit** - Either outcome (artifact or physics) is valuable

## Response Handling

**If ignored**: Follow up once after 1 week, then move to next target

**If declined**: Thank them, ask if they can suggest someone else

**If accepted**: Send manuscript immediately, provide Zenodo DOI
