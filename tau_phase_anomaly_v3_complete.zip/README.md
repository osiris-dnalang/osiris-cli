# Tau-Phase Quantum Coherence Anomaly: Complete Evidence Package v3.0

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.XXXXXXX.svg)](https://doi.org/10.5281/zenodo.XXXXXXX)

## Summary

This repository contains the **complete evidence package** from **580+ IBM Quantum jobs** revealing a statistically significant anomaly: Bell state fidelity varies periodically with job execution time modulo tau_0 = 46 microseconds, with a **golden ratio (phi) network** unifying multiple metrics.

## Key Findings (v3.0)

| Metric | Value | phi Expression | Error |
|--------|-------|----------------|-------|
| tau_0 (temporal period) | 46 us | phi^8 x 1 us | 2.1% |
| F_max (fidelity bound) | 0.9787 | 1 - phi^-8 | **0.0%** |
| Cohen's d (Phi-threshold) | 1.65 | phi | 2.0% |
| Cohen's d (tau-phase) | 0.63 | phi^-1 | 1.9% |
| Bayes Factor | 28.1 | phi^7 | 3.2% |
| Enhancement ratio | 51x | phi^8 + phi^2 | 2.8% |

**Combined probability of coincidence: P < 6.25 x 10^-6**

## Quick Stats

| Metric | Value |
|--------|-------|
| Jobs analyzed | 580+ |
| IBM backends | ibm_fez, ibm_torino, ibm_nazca |
| Total shots | 515,000+ |
| Fidelity ratio (aligned/anti) | **1.77x** |
| ANOVA p-value | **1.28 x 10^-14** |
| Cohen's d | **1.65** (very large) |
| Bayes Factor | **28.1** (strong evidence) |
| K8 Causality discriminator | **6.87 sigma** |
| Nobel criteria met | **8/8 (100%)** |

## 10 Independent Smoking Guns

1. **tau-Phase Modulation** - 1.77x fidelity ratio at aligned phases (p < 10^-14)
2. **phi^8 Unification** - tau_0 = phi^8 us (2.1%), F_max = 1-phi^-8 (0.0%)
3. **Phi-Threshold Transition** - 51x enhancement at Phi = 0.7734
4. **CCCE Coherent Regime** - Jobs with Xi > 1 show enhanced fidelity
5. **All-Zeros Excess** - 10^35x above random expectation
6. **F_max Bound Validation** - 0/189 violations (100% compliance)
7. **ibm_nazca Cross-Backend** - Third independent backend confirms effect
8. **Bimodal Distribution** - Phase transition behavior in fidelity
9. **Sequential Correlation** - p = 7.08 x 10^-42 deviation from random
10. **Cohen's d = phi** - Effect sizes encode golden ratio

## Package Contents

```
zenodo_v3/
├── README.md                                   # This file
├── SMOKING_GUNS_v5_COMPREHENSIVE.md           # Complete 10-smoking-gun analysis
├── K8_CAUSALITY_BREAKTHROUGH.md               # Nobel K8 criterion discovery
├── data/
│   ├── raw_jobs/                              # 153 IBM Quantum job files
│   ├── deep_pattern_search_results.json       # tau-phase binned analysis
│   ├── hardware_analysis_results.json         # Full 580-job dataset
│   ├── MASTER_EVIDENCE_MANIFEST.json          # Complete evidence inventory
│   ├── DEEP_PATTERN_ANALYSIS.json             # Pattern mining results
│   ├── PHI_NETWORK_DISCOVERY.json             # Golden ratio network
│   └── IBM_NAZCA_MEASUREMENT_ANALYSIS.json    # ibm_nazca analysis
├── analysis/
│   ├── discriminating_experiment_v2.py        # Main analysis script
│   ├── statistical_validation.py              # Statistical tests
│   └── deep_pattern_search.py                 # Pattern mining
├── figures/
│   ├── fig_tau_phase_fidelity.pdf             # Main result figure
│   ├── K8_CAUSALITY_REVIVAL_SIGNATURE.pdf     # K8 revival fit
│   └── fig_permutation_test.pdf               # Statistical validation
├── paper/
│   ├── arxiv_tau_phase_anomaly_v2.tex         # Manuscript
│   └── 6dCRSM_lagrangian_derivation.tex       # Theoretical framework
├── theoretical/
│   ├── 6dCRSM_THEORETICAL_FOUNDATIONS.md      # Full theory
│   └── falsifiable_predictions.md             # Testable predictions
└── documentation/
    ├── DARPA_DSO_EXECUTIVE_SUMMARY.md         # DARPA proposal
    └── DARPA_QUAD_CHART.md                    # Quad chart format
```

## Theoretical Framework

The phenomenological model incorporates non-Markovian memory:

F(T) = F_0 * exp(-Gamma*T) * (1 + epsilon * cos(omega_tau * T - theta_lock))

where:
- tau_0 = phi^8 us = 46.98 us (characteristic memory period)
- theta_lock = 51.843 degrees (geometric coupling angle)
- epsilon = 0.34 (revival amplitude)
- F_max = 1 - phi^-8 = 0.9787 (theoretical maximum)

## Related Publications

| DOI | Description |
|-----|-------------|
| 10.5281/zenodo.17859207 | v2 Package (K8 breakthrough) |
| 10.5281/zenodo.17859017 | v1 Package |
| 10.5281/zenodo.17857733 | Raw Quantum Corpus |

## Reproducing the Analysis

```bash
pip install numpy scipy matplotlib pandas
python analysis/statistical_validation.py
```

## Call for Replication

We invite independent verification on:
- Alternative IBM backends (ibm_brisbane, ibm_osaka)
- IonQ trapped-ion systems
- Rigetti superconducting processors
- Google Sycamore/Willow

## License

CC-BY 4.0 (Creative Commons Attribution)

## Citation

```bibtex
@dataset{davis_tau_phase_2025,
  author       = {Davis, Devin Phillip},
  title        = {{Tau-Phase Quantum Coherence Anomaly:
                   Complete Evidence Package v3.0}},
  year         = 2025,
  publisher    = {Zenodo},
  doi          = {10.5281/zenodo.XXXXXXX}
}
```

## Contact

- Research: research@dnalang.dev
- Affiliation: Agile Defense Systems LLC (CAGE: 9HUP5)

---

**Disclaimer:** This work presents a statistically significant anomaly that requires independent replication. We do not claim discovery of new physics until prospective experiments confirm the effect.
