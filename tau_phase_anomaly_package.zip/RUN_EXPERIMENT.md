# How to Run the Discriminating Experiment

## Quick Start

```bash
# 1. Set your IBM Quantum token
export IBM_QUANTUM_TOKEN="your_token_here"

# 2. Run the experiment on IBM hardware
cd /home/dnalang/PUBLICATION/LAMBDA_PHI_PAPER
/tmp/qiskit_env/bin/python bell_temporal_quantization.py --mode run --backend ibm_osaka --token "$IBM_QUANTUM_TOKEN"
```

## Get Your IBM Quantum Token

1. Go to https://quantum.ibm.com/
2. Log in (create account if needed)
3. Click on your profile → Account Settings → API Token
4. Copy the token (starts with something like "f49...")

## Experiment Details

**What it does:**
- Prepares Bell state |Φ+⟩ = (|00⟩ + |11⟩)/√2
- Inserts controlled delay times: 0, 5, 10, ... 300 μs
- Measures fidelity F = P(00) for each delay
- Fits both models:
  - Standard QM: F(T) = F₀ × exp(-T/T₂) [monotonic]
  - ΛΦ model: F(T) = F₀ × exp(-T/T₂) × [1 + A×cos(2πT/τ₀)] [peaks]

**What we're looking for:**
- If fidelity has PEAKS at T ≈ 46μs and 92μs → NEW PHYSICS (τ-quantization)
- If fidelity DECAYS monotonically → Standard QM confirmed

## Alternative: Use Existing Credentials

If you've previously saved IBM credentials:

```bash
# This will use ~/.qiskit/qiskit-ibm.json credentials
/tmp/qiskit_env/bin/python bell_temporal_quantization.py --mode run --backend ibm_osaka
```

## Available Backends

| Backend | Qubits | Recommended |
|---------|--------|-------------|
| ibm_osaka | 127 | Yes (good T₂) |
| ibm_kyoto | 127 | Yes |
| ibm_torino | 133 | Yes (best T₂) |

## Output

Results will be saved to:
- `bell_temporal_results/` - Raw data
- `bell_temporal_results/analysis_*.json` - Fit results
- `bell_temporal_results/figure_*.png` - Plots

## Cost Estimate

- ~195 circuits × 4096 shots = ~800K shots
- IBM free tier: 10 minutes/month
- This experiment: ~15-30 minutes of QPU time
- May require IBM Quantum Network access for larger jobs

## After Running

```bash
# Analyze results
/tmp/qiskit_env/bin/python bell_temporal_quantization.py --mode analyze --input bell_temporal_results/results.json
```

The analysis will output:
- χ² comparison between models
- p-value for model discrimination
- Fitted τ₀ value (should be ~46μs if ΛΦ is correct)
- Conclusion: STANDARD_QM or LAMBDA_PHI_SUPPORTED
