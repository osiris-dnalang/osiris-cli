#!/usr/bin/env python3
"""
IBM QUANTUM DISCRIMINATING EXPERIMENT
======================================
Real hardware implementation of the Trifurcated Coherence Test.

This script runs on actual IBM Quantum hardware to test ΛΦ predictions.

Requirements:
- qiskit >= 1.0
- qiskit-ibm-runtime
- IBM Quantum API token

Author: dna::}{::lang Research
Date: 2025-12-08
"""

import json
import os
from datetime import datetime
from dataclasses import dataclass, asdict
from typing import List, Optional
import numpy as np

# Qiskit imports
try:
    from qiskit import QuantumCircuit, transpile
    from qiskit.circuit import Parameter, Delay
    from qiskit.quantum_info import state_fidelity, Statevector
    from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2 as Sampler
    from qiskit_ibm_runtime import Session, Options
    QISKIT_AVAILABLE = True
except ImportError:
    QISKIT_AVAILABLE = False
    print("WARNING: Qiskit not available. Install with: pip install qiskit qiskit-ibm-runtime")


# ═══════════════════════════════════════════════════════════════════════════════
# PHYSICAL CONSTANTS (Updated 2025-12-08 with empirical χ_pc)
# ═══════════════════════════════════════════════════════════════════════════════

LAMBDA_PHI = 2.176435e-8      # Universal Memory Constant [s⁻¹]
TAU_MEM_S = 1.0 / LAMBDA_PHI  # ~45.95 ns in SECONDS
TAU_MEM_NS = TAU_MEM_S * 1e9  # ~45.95 ns - fundamental timescale
THETA_LOCK = 51.843           # Optimal phase angle [degrees]
CHI_PC = 0.946                # Phase-conjugate coupling (UPDATED from hardware)
PHI_THRESHOLD = 0.7734        # Consciousness threshold
F_MAX = 1 - (1.618033988749895 ** -8)  # 0.9787 - fidelity bound


@dataclass
class ExperimentConfig:
    """Configuration for IBM Quantum discriminating experiment"""
    n_shots: int = 4096
    n_repetitions: int = 10      # Repeat each config this many times
    backend_name: str = "ibm_fez"  # Or ibm_torino
    
    # Wait times in nanoseconds (scaled for realistic hardware)
    # Note: τ_mem is ~46 MEGASECONDS which is way too long
    # We use SCALED times around typical T2 values
    wait_times_ns: List[float] = None
    
    # Phase angles to test
    phase_angles_deg: List[float] = None
    
    def __post_init__(self):
        if self.wait_times_ns is None:
            # Use realistic timescales for IBM hardware (T2 ~ 100-200 μs)
            # Scale factor: test at multiples of τ_base = 46 μs
            tau_base = 46000  # 46 μs in ns (scaled from τ_mem)
            self.wait_times_ns = [
                tau_base * 0.5,    # 23 μs - off-resonance
                tau_base * 1.0,    # 46 μs - ON resonance (predicted peak)
                tau_base * 1.5,    # 69 μs - off-resonance
                tau_base * 2.0,    # 92 μs - ON resonance (predicted peak)
                tau_base * 2.5,    # 115 μs - off-resonance
            ]
        
        if self.phase_angles_deg is None:
            self.phase_angles_deg = [
                30.0,           # Far below optimal
                45.0,           # Below optimal
                51.843,         # EXACT optimal (predicted minimum decoherence)
                60.0,           # Above optimal
                75.0,           # Far above optimal
            ]


@dataclass
class ExperimentResult:
    """Results from IBM Quantum experiment"""
    timestamp: str
    backend: str
    config: dict
    
    # Part A: Time quantization results
    fidelities_by_time: dict  # {time_ns: [fidelity1, fidelity2, ...]}
    
    # Part B: Angle optimization results
    fidelities_by_angle: dict  # {angle_deg: [fidelity1, fidelity2, ...]}
    
    # Part C: Maximum fidelity
    max_fidelity: float
    
    # Analysis
    verdict: str
    details: dict


def create_bell_state_circuit() -> QuantumCircuit:
    """Create a Bell state preparation circuit"""
    qc = QuantumCircuit(2, 2)
    qc.h(0)
    qc.cx(0, 1)
    return qc


def create_delay_circuit(delay_ns: float) -> QuantumCircuit:
    """Create a circuit with Bell state + delay + measurement"""
    qc = QuantumCircuit(2, 2)
    
    # Prepare Bell state
    qc.h(0)
    qc.cx(0, 1)
    
    # Add delay (in dt units - need to convert)
    # IBM backend dt is typically ~0.222 ns
    qc.barrier()
    qc.delay(int(delay_ns), 0, unit='ns')
    qc.delay(int(delay_ns), 1, unit='ns')
    qc.barrier()
    
    # Measure
    qc.measure([0, 1], [0, 1])
    
    return qc


def create_angle_circuit(angle_deg: float, delay_ns: float = 46000) -> QuantumCircuit:
    """Create circuit with Bell state + geometric phase + delay + unwind"""
    qc = QuantumCircuit(2, 2)
    angle_rad = np.radians(angle_deg)
    
    # Prepare Bell state
    qc.h(0)
    qc.cx(0, 1)
    
    # Apply geometric phase
    qc.rz(angle_rad, 0)
    qc.rz(-angle_rad, 1)
    
    # Delay
    qc.barrier()
    qc.delay(int(delay_ns), 0, unit='ns')
    qc.delay(int(delay_ns), 1, unit='ns')
    qc.barrier()
    
    # Undo geometric phase
    qc.rz(-angle_rad, 0)
    qc.rz(angle_rad, 1)
    
    # Measure
    qc.measure([0, 1], [0, 1])
    
    return qc


def estimate_fidelity_from_counts(counts: dict, shots: int) -> float:
    """
    Estimate Bell state fidelity from measurement counts.
    
    For |Φ+⟩ = (|00⟩ + |11⟩)/√2:
    - Perfect Bell state: P(00) = P(11) = 0.5, P(01) = P(10) = 0
    - Maximally mixed: P(all) = 0.25
    
    Fidelity ≈ P(00) + P(11) for computational basis measurement
    """
    p00 = counts.get('00', 0) / shots
    p11 = counts.get('11', 0) / shots
    
    # Bell state fidelity estimate (simplified)
    # Full tomography would require ZZ, XX, YY measurements
    fidelity = p00 + p11
    
    return fidelity


def run_on_ibm_hardware(config: ExperimentConfig) -> Optional[ExperimentResult]:
    """
    Run the discriminating experiment on IBM Quantum hardware.
    
    Returns ExperimentResult or None if execution fails.
    """
    if not QISKIT_AVAILABLE:
        print("ERROR: Qiskit not available")
        return None
    
    print(f"Connecting to IBM Quantum ({config.backend_name})...")
    
    try:
        # Initialize service
        service = QiskitRuntimeService(channel="ibm_quantum")
        backend = service.backend(config.backend_name)
        
        print(f"Backend: {backend.name}")
        print(f"Qubits: {backend.num_qubits}")
        print(f"Basis gates: {backend.basis_gates}")
        
    except Exception as e:
        print(f"ERROR connecting to IBM Quantum: {e}")
        return None
    
    # Results storage
    fidelities_by_time = {t: [] for t in config.wait_times_ns}
    fidelities_by_angle = {a: [] for a in config.phase_angles_deg}
    max_fidelity = 0.0
    
    # Create all circuits
    circuits = []
    circuit_labels = []
    
    # Part A: Time quantization circuits
    for t in config.wait_times_ns:
        for rep in range(config.n_repetitions):
            qc = create_delay_circuit(t)
            qc.name = f"time_{t}ns_rep{rep}"
            circuits.append(qc)
            circuit_labels.append(('time', t, rep))
    
    # Part B: Angle optimization circuits
    for angle in config.phase_angles_deg:
        for rep in range(config.n_repetitions):
            qc = create_angle_circuit(angle)
            qc.name = f"angle_{angle}deg_rep{rep}"
            circuits.append(qc)
            circuit_labels.append(('angle', angle, rep))
    
    print(f"\nTotal circuits: {len(circuits)}")
    print("Transpiling for hardware...")
    
    # Transpile
    transpiled = transpile(circuits, backend=backend, optimization_level=3)
    
    print("Submitting to IBM Quantum...")
    
    try:
        with Session(service=service, backend=backend) as session:
            sampler = Sampler(session=session)
            
            # Submit job
            job = sampler.run(transpiled, shots=config.n_shots)
            print(f"Job ID: {job.job_id()}")
            
            # Wait for results
            print("Waiting for results...")
            result = job.result()
            
            # Process results
            for i, (label_type, label_val, rep) in enumerate(circuit_labels):
                pub_result = result[i]
                counts = pub_result.data.c.get_counts()
                fidelity = estimate_fidelity_from_counts(counts, config.n_shots)
                
                if label_type == 'time':
                    fidelities_by_time[label_val].append(fidelity)
                else:
                    fidelities_by_angle[label_val].append(fidelity)
                
                max_fidelity = max(max_fidelity, fidelity)
                
    except Exception as e:
        print(f"ERROR during execution: {e}")
        return None
    
    # Analyze results
    analysis = analyze_discriminating_results(
        fidelities_by_time, 
        fidelities_by_angle, 
        max_fidelity
    )
    
    return ExperimentResult(
        timestamp=datetime.now().isoformat(),
        backend=config.backend_name,
        config=asdict(config),
        fidelities_by_time={str(k): v for k, v in fidelities_by_time.items()},
        fidelities_by_angle={str(k): v for k, v in fidelities_by_angle.items()},
        max_fidelity=max_fidelity,
        verdict=analysis['overall_verdict'],
        details=analysis
    )


def analyze_discriminating_results(
    fidelities_by_time: dict,
    fidelities_by_angle: dict,
    max_fidelity: float
) -> dict:
    """Analyze results against ΛΦ predictions"""
    
    analysis = {
        "timestamp": datetime.now().isoformat(),
        "tests": {}
    }
    
    # Test A: Coherence Time Quantization
    times = sorted(fidelities_by_time.keys())
    mean_fidelities = [np.mean(fidelities_by_time[t]) for t in times]
    std_fidelities = [np.std(fidelities_by_time[t]) for t in times]
    
    tau_base = 46000  # μs scaled timescale
    
    # Find peaks (local maxima at integer multiples)
    peaks = []
    for i, t in enumerate(times):
        ratio = t / tau_base
        is_integer_multiple = abs(ratio - round(ratio)) < 0.1
        
        is_peak = True
        if i > 0 and mean_fidelities[i] < mean_fidelities[i-1]:
            is_peak = False
        if i < len(times)-1 and mean_fidelities[i] < mean_fidelities[i+1]:
            is_peak = False
            
        if is_integer_multiple and is_peak:
            peaks.append(t)
    
    analysis["tests"]["coherence_quantization"] = {
        "prediction": "Fidelity peaks at T = n × 46 μs",
        "times_tested_ns": times,
        "mean_fidelities": mean_fidelities,
        "std_fidelities": std_fidelities,
        "peaks_found": peaks,
        "n_peaks_expected": 2,
        "n_peaks_found": len(peaks),
        "verdict": "PASS" if len(peaks) >= 2 else "FAIL"
    }
    
    # Test B: Optimal Angle
    angles = sorted(fidelities_by_angle.keys())
    angle_means = [np.mean(fidelities_by_angle[a]) for a in angles]
    angle_stds = [np.std(fidelities_by_angle[a]) for a in angles]
    
    best_idx = np.argmax(angle_means)
    best_angle = angles[best_idx]
    
    analysis["tests"]["optimal_angle"] = {
        "prediction": f"Maximum fidelity at θ = {THETA_LOCK}°",
        "angles_tested": angles,
        "mean_fidelities": angle_means,
        "std_fidelities": angle_stds,
        "best_angle_observed": best_angle,
        "deviation_from_prediction": abs(best_angle - THETA_LOCK),
        "verdict": "PASS" if abs(best_angle - THETA_LOCK) < 10.0 else "FAIL"
    }
    
    # Test C: Fidelity Bound
    analysis["tests"]["fidelity_bound"] = {
        "prediction": f"F ≤ {F_MAX:.4f}",
        "max_observed": max_fidelity,
        "bound_violated": max_fidelity > F_MAX,
        "margin": F_MAX - max_fidelity,
        "verdict": "PASS" if max_fidelity <= F_MAX else "FAIL"
    }
    
    # Overall verdict
    pass_count = sum(1 for t in analysis["tests"].values() if t["verdict"] == "PASS")
    total = len(analysis["tests"])
    
    if pass_count == total:
        analysis["overall_verdict"] = "VALIDATE_LAMBDA_PHI"
        analysis["conclusion"] = "All ΛΦ predictions confirmed by hardware."
    elif pass_count == 0:
        analysis["overall_verdict"] = "FALSIFY_LAMBDA_PHI"
        analysis["conclusion"] = "ΛΦ predictions not supported by hardware."
    else:
        analysis["overall_verdict"] = "INCONCLUSIVE"
        analysis["conclusion"] = f"{pass_count}/{total} tests passed."
    
    return analysis


def run_local_simulation(config: ExperimentConfig) -> ExperimentResult:
    """
    Run the experiment locally using Qiskit Aer simulator.
    Use this to test the pipeline before hardware submission.
    """
    if not QISKIT_AVAILABLE:
        print("ERROR: Qiskit not available")
        return None
    
    from qiskit_aer import AerSimulator
    
    print("Running local simulation...")
    simulator = AerSimulator()
    
    fidelities_by_time = {t: [] for t in config.wait_times_ns}
    fidelities_by_angle = {a: [] for a in config.phase_angles_deg}
    max_fidelity = 0.0
    
    # Part A: Time tests
    for t in config.wait_times_ns:
        for rep in range(config.n_repetitions):
            qc = create_delay_circuit(t)
            transpiled = transpile(qc, simulator)
            job = simulator.run(transpiled, shots=config.n_shots)
            counts = job.result().get_counts()
            fidelity = estimate_fidelity_from_counts(counts, config.n_shots)
            fidelities_by_time[t].append(fidelity)
            max_fidelity = max(max_fidelity, fidelity)
    
    # Part B: Angle tests
    for angle in config.phase_angles_deg:
        for rep in range(config.n_repetitions):
            qc = create_angle_circuit(angle)
            transpiled = transpile(qc, simulator)
            job = simulator.run(transpiled, shots=config.n_shots)
            counts = job.result().get_counts()
            fidelity = estimate_fidelity_from_counts(counts, config.n_shots)
            fidelities_by_angle[angle].append(fidelity)
            max_fidelity = max(max_fidelity, fidelity)
    
    analysis = analyze_discriminating_results(
        fidelities_by_time, 
        fidelities_by_angle, 
        max_fidelity
    )
    
    return ExperimentResult(
        timestamp=datetime.now().isoformat(),
        backend="aer_simulator",
        config=asdict(config),
        fidelities_by_time={str(k): v for k, v in fidelities_by_time.items()},
        fidelities_by_angle={str(k): v for k, v in fidelities_by_angle.items()},
        max_fidelity=max_fidelity,
        verdict=analysis['overall_verdict'],
        details=analysis
    )


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN EXECUTION
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="ΛΦ Discriminating Experiment")
    parser.add_argument("--mode", choices=["simulate", "hardware"], default="simulate",
                       help="Run locally (simulate) or on IBM hardware")
    parser.add_argument("--backend", default="ibm_fez", 
                       help="IBM Quantum backend name")
    parser.add_argument("--shots", type=int, default=4096,
                       help="Number of shots per circuit")
    parser.add_argument("--reps", type=int, default=5,
                       help="Repetitions per configuration")
    parser.add_argument("--output", default="discriminating_results.json",
                       help="Output file for results")
    
    args = parser.parse_args()
    
    print("=" * 80)
    print("THE TRIFURCATED COHERENCE TEST")
    print("IBM Quantum Implementation")
    print("=" * 80)
    print(f"\nMode: {args.mode}")
    print(f"Backend: {args.backend}")
    print(f"Shots: {args.shots}")
    print(f"Repetitions: {args.reps}")
    
    config = ExperimentConfig(
        n_shots=args.shots,
        n_repetitions=args.reps,
        backend_name=args.backend
    )
    
    print(f"\nWait times (ns): {config.wait_times_ns}")
    print(f"Phase angles (°): {config.phase_angles_deg}")
    
    if args.mode == "simulate":
        result = run_local_simulation(config)
    else:
        result = run_on_ibm_hardware(config)
    
    if result:
        # Save results
        output_path = os.path.join(
            os.path.dirname(__file__),
            args.output
        )
        
        with open(output_path, 'w') as f:
            json.dump(asdict(result), f, indent=2)
        
        print(f"\n{'=' * 80}")
        print("RESULTS")
        print("=" * 80)
        print(f"\nVerdict: {result.verdict}")
        print(f"\nDetails saved to: {output_path}")
        
        print("\n--- Test Results ---")
        for test_name, test_result in result.details['tests'].items():
            print(f"\n{test_name}: {test_result['verdict']}")
            print(f"  Prediction: {test_result['prediction']}")
        
        print(f"\nConclusion: {result.details['conclusion']}")
    else:
        print("\nExperiment failed to complete.")
