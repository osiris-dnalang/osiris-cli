#!/usr/bin/env python3
"""
Ledger Automation and Model Comparison Module
Nobel Protocol v1.1 - Integrity Automation Layer

Automates:
1. SHA-256 checksum generation
2. Model comparison (AIC/BIC)
3. Run log entry generation
4. Verification ledger updates
5. Nobel-protocol threshold checking

Author: Devin Phillip Davis
Organization: Agile Defense Systems LLC (CAGE: 9HUP5)
"""

import numpy as np
from scipy.optimize import curve_fit
from scipy.stats import chi2
from datetime import datetime
import json
import hashlib
import os
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import Optional, Tuple, Dict, List

# =============================================================================
# Physical Constants
# =============================================================================
LAMBDA_PHI = 2.176435e-8  # Universal memory constant [s⁻¹]
TAU_0_PREDICTED = 46.0    # Predicted revival period [μs]
THETA_LOCK = 51.843       # Torsion-locked angle [degrees]
PHI_THRESHOLD = 0.7734    # Consciousness threshold

# =============================================================================
# Nobel Protocol Thresholds
# =============================================================================
@dataclass
class NobelThresholds:
    """Discovery-class thresholds per Nobel Protocol v1.1"""
    delta_aic_min: float = 10.0       # ΔAIC > 10
    delta_bic_min: float = 10.0       # ΔBIC > 10
    amplitude_sigma_min: float = 5.0  # A/σ_A ≥ 5
    tau_deviation_max: float = 3.0    # |τ_fitted - 46| ≤ 3 μs
    p_value_max: float = 1e-6         # p < 10⁻⁶
    min_backends: int = 2             # Reproduced on ≥ 2 backends


# =============================================================================
# Model Definitions
# =============================================================================
def exponential_decay(t: np.ndarray, f0: float, t2: float) -> np.ndarray:
    """Standard QM exponential decay model."""
    return f0 * np.exp(-t / t2)


def revival_model(t: np.ndarray, f0: float, t2: float,
                  tau0: float, amplitude: float) -> np.ndarray:
    """ΛΦ revival model with τ-locked oscillations."""
    envelope = f0 * np.exp(-t / t2)
    modulation = 1 + amplitude * np.cos(2 * np.pi * t / tau0)
    return envelope * modulation


# =============================================================================
# Model Comparison
# =============================================================================
@dataclass
class FitResult:
    """Result of a model fit."""
    model_name: str
    parameters: Dict[str, float]
    parameter_errors: Dict[str, float]
    chi_squared: float
    dof: int
    reduced_chi_squared: float
    aic: float
    bic: float
    residuals: np.ndarray


@dataclass
class ModelComparison:
    """Comparison between two models."""
    model1: FitResult
    model2: FitResult
    delta_chi2: float
    delta_aic: float
    delta_bic: float
    p_value: float
    preferred_model: str
    evidence_strength: str


def calculate_aic(chi2_val: float, k: int) -> float:
    """Calculate Akaike Information Criterion."""
    return chi2_val + 2 * k


def calculate_bic(chi2_val: float, k: int, n: int) -> float:
    """Calculate Bayesian Information Criterion."""
    return chi2_val + k * np.log(n)


def fit_exponential(t_data: np.ndarray, f_data: np.ndarray,
                    f_err: np.ndarray) -> FitResult:
    """Fit exponential decay model."""
    try:
        popt, pcov = curve_fit(
            exponential_decay, t_data, f_data,
            p0=[0.95, 150],
            sigma=f_err,
            absolute_sigma=True,
            bounds=([0.5, 50], [1.0, 500])
        )
        perr = np.sqrt(np.diag(pcov))

        pred = exponential_decay(t_data, *popt)
        residuals = f_data - pred
        chi2_val = np.sum((residuals / f_err)**2)
        dof = len(t_data) - 2

        return FitResult(
            model_name="Exponential Decay",
            parameters={"f0": popt[0], "t2": popt[1]},
            parameter_errors={"f0": perr[0], "t2": perr[1]},
            chi_squared=chi2_val,
            dof=dof,
            reduced_chi_squared=chi2_val / dof,
            aic=calculate_aic(chi2_val, 2),
            bic=calculate_bic(chi2_val, 2, len(t_data)),
            residuals=residuals
        )
    except Exception as e:
        raise ValueError(f"Exponential fit failed: {e}")


def fit_revival(t_data: np.ndarray, f_data: np.ndarray,
                f_err: np.ndarray) -> FitResult:
    """Fit ΛΦ revival model."""
    try:
        popt, pcov = curve_fit(
            revival_model, t_data, f_data,
            p0=[0.95, 150, 46, 0.1],
            sigma=f_err,
            absolute_sigma=True,
            bounds=([0.5, 50, 20, 0], [1.0, 500, 100, 0.5])
        )
        perr = np.sqrt(np.diag(pcov))

        pred = revival_model(t_data, *popt)
        residuals = f_data - pred
        chi2_val = np.sum((residuals / f_err)**2)
        dof = len(t_data) - 4

        return FitResult(
            model_name="ΛΦ Revival",
            parameters={"f0": popt[0], "t2": popt[1], "tau0": popt[2], "amplitude": popt[3]},
            parameter_errors={"f0": perr[0], "t2": perr[1], "tau0": perr[2], "amplitude": perr[3]},
            chi_squared=chi2_val,
            dof=dof,
            reduced_chi_squared=chi2_val / dof,
            aic=calculate_aic(chi2_val, 4),
            bic=calculate_bic(chi2_val, 4, len(t_data)),
            residuals=residuals
        )
    except Exception as e:
        raise ValueError(f"Revival fit failed: {e}")


def compare_models(exp_fit: FitResult, rev_fit: FitResult) -> ModelComparison:
    """Compare exponential and revival models."""
    delta_chi2 = exp_fit.chi_squared - rev_fit.chi_squared
    delta_dof = 2  # Revival has 2 more parameters

    # p-value for chi-squared improvement
    p_value = 1 - chi2.cdf(max(0, delta_chi2), delta_dof)

    delta_aic = exp_fit.aic - rev_fit.aic
    delta_bic = exp_fit.bic - rev_fit.bic

    # Model preference
    if delta_aic > 10 and delta_bic > 10:
        preferred = "Revival"
        strength = "STRONG"
    elif delta_aic > 4 or delta_bic > 4:
        preferred = "Revival"
        strength = "MODERATE"
    elif delta_aic < -10 and delta_bic < -10:
        preferred = "Exponential"
        strength = "STRONG"
    elif delta_aic < -4 or delta_bic < -4:
        preferred = "Exponential"
        strength = "MODERATE"
    else:
        preferred = "Inconclusive"
        strength = "WEAK"

    return ModelComparison(
        model1=exp_fit,
        model2=rev_fit,
        delta_chi2=delta_chi2,
        delta_aic=delta_aic,
        delta_bic=delta_bic,
        p_value=p_value,
        preferred_model=preferred,
        evidence_strength=strength
    )


# =============================================================================
# Nobel Protocol Classification
# =============================================================================
@dataclass
class NobelClassification:
    """Classification result per Nobel Protocol v1.1"""
    classification: str  # DISCOVERY-CLASS, STRONG EVIDENCE, SUGGESTIVE, NULL RESULT
    conditions_met: int
    conditions_details: Dict[str, bool]
    recommendation: str


def classify_result(comparison: ModelComparison,
                    backends_validated: int = 1) -> NobelClassification:
    """Classify result according to Nobel Protocol thresholds."""
    thresholds = NobelThresholds()

    # Get revival parameters
    tau_fitted = comparison.model2.parameters.get("tau0", 0)
    amplitude = comparison.model2.parameters.get("amplitude", 0)
    amplitude_err = comparison.model2.parameter_errors.get("amplitude", 1)

    conditions = {
        "ΔAIC > 10": comparison.delta_aic > thresholds.delta_aic_min,
        "ΔBIC > 10": comparison.delta_bic > thresholds.delta_bic_min,
        "A/σ_A ≥ 5": (amplitude / amplitude_err) >= thresholds.amplitude_sigma_min if amplitude_err > 0 else False,
        "|τ - 46| ≤ 3 μs": abs(tau_fitted - TAU_0_PREDICTED) <= thresholds.tau_deviation_max,
        "p < 10⁻⁶": comparison.p_value < thresholds.p_value_max,
        "≥2 backends": backends_validated >= thresholds.min_backends
    }

    conditions_met = sum(conditions.values())

    if conditions_met == 6:
        classification = "DISCOVERY-CLASS"
        recommendation = "Prepare Nobel nomination packet. Submit to PRX Quantum and Nature Physics."
    elif conditions_met >= 4:
        classification = "STRONG EVIDENCE"
        recommendation = "Seek immediate cross-vendor validation on IonQ/Rigetti."
    elif conditions_met >= 2:
        classification = "SUGGESTIVE"
        recommendation = "Continue investigation. Rule out hardware artifacts."
    else:
        classification = "NULL RESULT"
        recommendation = "Standard QM confirmed. Document negative result."

    return NobelClassification(
        classification=classification,
        conditions_met=conditions_met,
        conditions_details=conditions,
        recommendation=recommendation
    )


# =============================================================================
# Ledger Management
# =============================================================================
def generate_run_id() -> str:
    """Generate unique run ID."""
    return f"RUN-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}"


def generate_run_log_entry(
    run_id: str,
    backend: str,
    script: str,
    comparison: ModelComparison,
    classification: NobelClassification,
    delay_config: Dict[str, float]
) -> str:
    """Generate markdown run log entry for the verification ledger."""

    exp = comparison.model1
    rev = comparison.model2

    entry = f"""
### Run ID: {run_id}

**Backend:** {backend}
**API Key Owner:** research@dnalang.dev
**Script:** {script}
**Timestamp:** {datetime.utcnow().isoformat()}Z

**Delay Sweep:**
  T_min    = {delay_config.get('t_min', 0)} μs
  T_max    = {delay_config.get('t_max', 300)} μs
  ΔT       = {delay_config.get('dt', 5)} μs
  Shots    = {delay_config.get('shots', 4096)}

**Fit Model 1 (Exponential Decay):**
  F₀ = {exp.parameters['f0']:.4f} ± {exp.parameter_errors['f0']:.4f}
  T₂ = {exp.parameters['t2']:.1f} ± {exp.parameter_errors['t2']:.1f} μs
  χ²/dof = {exp.reduced_chi_squared:.3f}
  AIC = {exp.aic:.2f}
  BIC = {exp.bic:.2f}

**Fit Model 2 (ΛΦ Revival):**
  F₀ = {rev.parameters['f0']:.4f} ± {rev.parameter_errors['f0']:.4f}
  T₂ = {rev.parameters['t2']:.1f} ± {rev.parameter_errors['t2']:.1f} μs
  τ₀ = {rev.parameters['tau0']:.2f} ± {rev.parameter_errors['tau0']:.2f} μs (predicted: 46 μs)
  A  = {rev.parameters['amplitude']:.4f} ± {rev.parameter_errors['amplitude']:.4f}
  χ²/dof = {rev.reduced_chi_squared:.3f}
  AIC = {rev.aic:.2f}
  BIC = {rev.bic:.2f}

**Model Selection:**
  ΔAIC = {comparison.delta_aic:.2f}
  ΔBIC = {comparison.delta_bic:.2f}
  Δχ² = {comparison.delta_chi2:.2f}
  p-value = {comparison.p_value:.2e}
  Winner: {comparison.preferred_model} ({comparison.evidence_strength})

**τ-Phase Alignment:**
  τ₀ predicted  = 46.00 μs
  τ₀ fitted     = {rev.parameters['tau0']:.2f} μs
  |Δτ|          = {abs(rev.parameters['tau0'] - 46):.2f} μs
  Deviation     = {abs(rev.parameters['tau0'] - 46) / 46 * 100:.1f}%

**Significance Tests:**
  A/σ_A = {rev.parameters['amplitude'] / rev.parameter_errors['amplitude']:.2f}
  p-value (periodicity) = {comparison.p_value:.2e}

**Nobel Protocol Classification:**
  Classification: {classification.classification}
  Conditions Met: {classification.conditions_met}/6

  Condition Details:
"""

    for cond, met in classification.conditions_details.items():
        status = "✓" if met else "✗"
        entry += f"    [{status}] {cond}\n"

    entry += f"""
**Recommendation:** {classification.recommendation}

---
"""

    return entry


def compute_file_sha256(filepath: str) -> str:
    """Compute SHA-256 hash of a file."""
    sha256_hash = hashlib.sha256()
    with open(filepath, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest()


def generate_sha_manifest(directory: str, extensions: List[str]) -> Dict[str, str]:
    """Generate SHA-256 manifest for all files with given extensions."""
    manifest = {}
    path = Path(directory)

    for ext in extensions:
        for filepath in path.glob(f"*.{ext}"):
            manifest[filepath.name] = compute_file_sha256(str(filepath))

    return manifest


# =============================================================================
# Main Analysis Function
# =============================================================================
def analyze_experiment_results(
    delays_us: np.ndarray,
    fidelities: np.ndarray,
    fidelity_errors: np.ndarray,
    backend: str,
    script: str = "bell_temporal_quantization.py",
    backends_validated: int = 1
) -> Tuple[ModelComparison, NobelClassification, str]:
    """
    Complete analysis pipeline for experiment results.

    Returns:
        comparison: Model comparison results
        classification: Nobel protocol classification
        log_entry: Markdown log entry for verification ledger
    """
    # Fit both models
    exp_fit = fit_exponential(delays_us, fidelities, fidelity_errors)
    rev_fit = fit_revival(delays_us, fidelities, fidelity_errors)

    # Compare models
    comparison = compare_models(exp_fit, rev_fit)

    # Classify result
    classification = classify_result(comparison, backends_validated)

    # Generate run ID and log entry
    run_id = generate_run_id()
    delay_config = {
        "t_min": delays_us.min(),
        "t_max": delays_us.max(),
        "dt": np.median(np.diff(np.sort(delays_us))),
        "shots": 4096
    }

    log_entry = generate_run_log_entry(
        run_id, backend, script, comparison, classification, delay_config
    )

    return comparison, classification, log_entry


# =============================================================================
# CLI Interface
# =============================================================================
def main():
    """Command-line interface for ledger automation."""
    import argparse

    parser = argparse.ArgumentParser(description="ΛΦ Ledger Automation Module")
    parser.add_argument("--mode", choices=["sha", "analyze", "demo"], default="demo",
                        help="Operation mode")
    parser.add_argument("--directory", default=".", help="Directory for SHA manifest")
    parser.add_argument("--input", help="Input results JSON for analysis")
    parser.add_argument("--backend", default="ibm_fez", help="Backend name")

    args = parser.parse_args()

    if args.mode == "sha":
        manifest = generate_sha_manifest(
            args.directory,
            ["tex", "py", "pdf", "md", "json", "ipynb"]
        )
        print("SHA-256 Manifest:")
        print("=" * 80)
        for filename, sha in sorted(manifest.items()):
            print(f"{sha}  {filename}")

    elif args.mode == "analyze":
        if not args.input:
            print("Error: --input required for analyze mode")
            return

        with open(args.input) as f:
            data = json.load(f)

        delays = np.array([d["delay_us"] for d in data["data"]])
        fids = np.array([d["fidelity"] for d in data["data"]])
        errs = np.ones_like(fids) * 0.015  # Assumed error

        comparison, classification, log_entry = analyze_experiment_results(
            delays, fids, errs, args.backend
        )

        print(log_entry)
        print("\n" + "=" * 80)
        print(f"CLASSIFICATION: {classification.classification}")
        print(f"Recommendation: {classification.recommendation}")

    elif args.mode == "demo":
        print("Nobel Protocol v1.1 - Ledger Automation Demo")
        print("=" * 60)

        # Generate synthetic data matching ΛΦ prediction
        np.random.seed(42)
        delays = np.linspace(0, 200, 40)
        true_fid = 0.94 * np.exp(-delays / 160) * (1 + 0.12 * np.cos(2 * np.pi * delays / 46))
        fids = true_fid + np.random.normal(0, 0.015, len(delays))
        errs = np.ones_like(fids) * 0.015

        comparison, classification, log_entry = analyze_experiment_results(
            delays, fids, errs, "synthetic_demo"
        )

        print(log_entry)
        print("\n" + "=" * 80)
        print(f"FINAL CLASSIFICATION: {classification.classification}")
        print("=" * 80)


if __name__ == "__main__":
    main()
