#!/usr/bin/env python3
"""
Analyze Existing IBM Quantum Hardware Data
==========================================
Extract timestamps, fidelities, and τ-phase correlations from
locally stored IBM job files WITHOUT needing an API token.

Nobel Protocol v1.1 - Offline Analysis Module
"""

import json
import base64
import numpy as np
from pathlib import Path
from datetime import datetime
from collections import defaultdict
import sys

# Physical constants
TAU_0 = 46e-6  # τ₀ = 46 μs
LAMBDA_PHI = 2.176435e-8  # Universal Memory Constant

def decode_bitarray(bitarray_data):
    """Decode BitArray from IBM result format to shot outcomes."""
    try:
        # Get the base64-encoded ndarray
        array_data = bitarray_data.get('array', {})
        if isinstance(array_data, dict) and array_data.get('__type__') == 'ndarray':
            encoded = array_data.get('__value__', '')
            # Decode base64
            raw_bytes = base64.b64decode(encoded)
            # Convert to numpy array of uint8
            arr = np.frombuffer(raw_bytes, dtype=np.uint8)
            return arr, bitarray_data.get('num_bits', 2)
    except Exception as e:
        return None, 0
    return None, 0

def extract_counts_from_bitarray(arr, num_bits, num_shots):
    """Extract measurement counts from decoded BitArray."""
    if arr is None:
        return None

    # Each shot takes ceil(num_bits/8) bytes
    bytes_per_shot = (num_bits + 7) // 8

    counts = defaultdict(int)

    for i in range(num_shots):
        start_idx = i * bytes_per_shot
        if start_idx >= len(arr):
            break

        # Extract the outcome bits
        outcome = 0
        for j in range(bytes_per_shot):
            if start_idx + j < len(arr):
                outcome |= arr[start_idx + j] << (8 * j)

        # Mask to num_bits
        outcome &= (1 << num_bits) - 1

        # Convert to bitstring
        bitstring = format(outcome, f'0{num_bits}b')
        counts[bitstring] += 1

    return dict(counts)

def calculate_fidelity(counts, num_bits=2):
    """Calculate Bell state fidelity F = P(00) + P(11) or just P(00)."""
    if not counts:
        return None

    total = sum(counts.values())
    if total == 0:
        return None

    # For Bell state |Φ+⟩, fidelity is P(00) + P(11)
    # But for this analysis, we track P(00) as primary metric
    p00 = counts.get('0' * num_bits, 0) / total
    p11 = counts.get('1' * num_bits, 0) / total if num_bits == 2 else 0

    return {
        'P00': p00,
        'P11': p11,
        'fidelity': p00 + p11,  # Bell fidelity
        'total_shots': total,
        'counts': counts
    }

def parse_datetime(dt_obj):
    """Parse datetime from various IBM formats."""
    if isinstance(dt_obj, dict) and dt_obj.get('__type__') == 'datetime':
        dt_str = dt_obj.get('__value__', '')
        try:
            return datetime.fromisoformat(dt_str.replace('Z', '+00:00'))
        except:
            return None
    elif isinstance(dt_obj, str):
        try:
            return datetime.fromisoformat(dt_str.replace('Z', '+00:00'))
        except:
            return None
    return None

def calculate_tau_phase(timestamp):
    """Calculate τ-phase from timestamp."""
    if timestamp is None:
        return None

    # Convert to Unix timestamp (seconds since epoch)
    unix_ts = timestamp.timestamp()

    # Calculate phase within τ₀ period
    phase = (unix_ts % TAU_0) / TAU_0
    return phase

def analyze_job_file(info_path, result_path):
    """Analyze a single job from its info and result files."""
    try:
        with open(info_path) as f:
            info = json.load(f)
        with open(result_path) as f:
            result = json.load(f)
    except Exception as e:
        return None

    # Extract basic info
    job_id = info.get('id', 'unknown')
    backend = info.get('backend', 'unknown')
    created = info.get('created', '')
    status = info.get('status', '')

    # Parse timestamp
    if isinstance(created, str):
        try:
            timestamp = datetime.fromisoformat(created.replace('Z', '+00:00'))
        except:
            timestamp = None
    else:
        timestamp = None

    # Extract shots from params
    shots = 2048  # default
    params = info.get('params', {})
    pubs = params.get('pubs', [])
    if pubs and len(pubs) > 0:
        if isinstance(pubs[0], list) and len(pubs[0]) >= 3:
            shots = pubs[0][2]

    # Extract circuit metadata if available
    circuit_name = None
    circuit_desc = None

    # Parse result
    result_value = result.get('__value__', result)
    pub_results = result_value.get('pub_results', [])

    fidelity_data = None
    execution_start = None
    execution_stop = None

    for pub in pub_results:
        pub_value = pub.get('__value__', pub) if isinstance(pub, dict) else pub

        # Get metadata
        metadata = pub_value.get('metadata', {})
        circuit_meta = metadata.get('circuit_metadata', {})
        circuit_name = circuit_meta.get('name', circuit_name)
        circuit_desc = circuit_meta.get('description', circuit_desc)

        # Get data
        data = pub_value.get('data', {})
        data_value = data.get('__value__', data) if isinstance(data, dict) else data

        if isinstance(data_value, dict):
            fields = data_value.get('fields', {})
            c_field = fields.get('c', {})
            if isinstance(c_field, dict) and c_field.get('__type__') == 'BitArray':
                bitarray = c_field.get('__value__', {})
                arr, num_bits = decode_bitarray(bitarray)
                if arr is not None:
                    counts = extract_counts_from_bitarray(arr, num_bits, shots)
                    fidelity_data = calculate_fidelity(counts, num_bits)

    # Get execution spans for more precise timing
    metadata = result_value.get('metadata', {})
    execution = metadata.get('execution', {})
    spans = execution.get('execution_spans', {})
    if isinstance(spans, dict) and spans.get('__type__') == 'ExecutionSpans':
        spans_value = spans.get('__value__', {})
        span_list = spans_value.get('spans', [])
        for span in span_list:
            if isinstance(span, dict):
                span_value = span.get('__value__', span)
                execution_start = parse_datetime(span_value.get('start'))
                execution_stop = parse_datetime(span_value.get('stop'))
                break

    # Use execution start if available, else created time
    effective_timestamp = execution_start or timestamp
    tau_phase = calculate_tau_phase(effective_timestamp)

    return {
        'job_id': job_id,
        'backend': backend,
        'created': created,
        'timestamp': effective_timestamp.isoformat() if effective_timestamp else None,
        'execution_start': execution_start.isoformat() if execution_start else None,
        'execution_stop': execution_stop.isoformat() if execution_stop else None,
        'status': status,
        'shots': shots,
        'circuit_name': circuit_name,
        'circuit_description': circuit_desc,
        'tau_phase': tau_phase,
        'fidelity': fidelity_data
    }

def main():
    """Main analysis routine."""
    job_dir = Path('/home/dnalang')
    output_dir = Path('/home/dnalang/PUBLICATION/LAMBDA_PHI_PAPER')

    # Find all job files
    info_files = sorted(job_dir.glob('job-*-info.json'))

    print(f"Found {len(info_files)} job info files")

    results = []
    backends = defaultdict(list)

    for info_path in info_files:
        job_id = info_path.stem.replace('-info', '').replace('job-', '')
        result_path = job_dir / f'job-{job_id}-result.json'

        if not result_path.exists():
            continue

        analysis = analyze_job_file(info_path, result_path)
        if analysis and analysis['fidelity']:
            results.append(analysis)
            backends[analysis['backend']].append(analysis)

            # Progress indicator
            sys.stdout.write(f"\rAnalyzed {len(results)} jobs...")
            sys.stdout.flush()

    print(f"\n\nSuccessfully analyzed {len(results)} jobs")
    print(f"\nBackends: {dict((k, len(v)) for k, v in backends.items())}")

    # Statistical analysis
    print("\n" + "="*60)
    print("τ-PHASE CORRELATION ANALYSIS")
    print("="*60)

    # Bin by τ-phase
    aligned_fidelities = []  # phase 0-0.5
    antialigned_fidelities = []  # phase 0.5-1.0

    phase_bins = defaultdict(list)

    for r in results:
        if r['tau_phase'] is not None and r['fidelity']:
            phase = r['tau_phase']
            fid = r['fidelity']['P00']  # Use P(00) as primary metric

            # 10-bin analysis
            bin_idx = int(phase * 10) % 10
            phase_bins[bin_idx].append(fid)

            # Binary split
            if phase < 0.5:
                aligned_fidelities.append(fid)
            else:
                antialigned_fidelities.append(fid)

    # Calculate statistics
    if aligned_fidelities and antialigned_fidelities:
        aligned_mean = np.mean(aligned_fidelities)
        antialigned_mean = np.mean(antialigned_fidelities)
        aligned_std = np.std(aligned_fidelities)
        antialigned_std = np.std(antialigned_fidelities)

        ratio = aligned_mean / antialigned_mean if antialigned_mean > 0 else float('inf')

        # Welch's t-test
        n1, n2 = len(aligned_fidelities), len(antialigned_fidelities)
        pooled_se = np.sqrt(aligned_std**2/n1 + antialigned_std**2/n2)
        t_stat = (aligned_mean - antialigned_mean) / pooled_se if pooled_se > 0 else 0

        # Cohen's d
        pooled_std = np.sqrt(((n1-1)*aligned_std**2 + (n2-1)*antialigned_std**2) / (n1+n2-2))
        cohens_d = (aligned_mean - antialigned_mean) / pooled_std if pooled_std > 0 else 0

        print(f"\nτ-aligned (phase 0-0.5):     N={n1}, Mean={aligned_mean:.4f} ± {aligned_std:.4f}")
        print(f"τ-anti-aligned (phase 0.5-1): N={n2}, Mean={antialigned_mean:.4f} ± {antialigned_std:.4f}")
        print(f"\nRatio: {ratio:.3f}×")
        print(f"t-statistic: {t_stat:.3f}")
        print(f"Cohen's d: {cohens_d:.3f}")

        # 10-bin analysis
        print("\n" + "-"*60)
        print("10-BIN τ-PHASE FIDELITY DISTRIBUTION")
        print("-"*60)
        print(f"{'Bin':>4} {'Phase Range':>15} {'N':>6} {'Mean F':>10} {'Std':>10}")
        print("-"*60)

        bin_stats = []
        for i in range(10):
            if phase_bins[i]:
                mean_f = np.mean(phase_bins[i])
                std_f = np.std(phase_bins[i])
                bin_stats.append({
                    'bin': i,
                    'phase_start': i/10,
                    'phase_end': (i+1)/10,
                    'n': len(phase_bins[i]),
                    'mean': mean_f,
                    'std': std_f
                })
                print(f"{i:>4} {i/10:.1f}-{(i+1)/10:.1f}         {len(phase_bins[i]):>6} {mean_f:>10.4f} {std_f:>10.4f}")

        # ANOVA-like analysis
        all_fids = [f for r in results if r['tau_phase'] is not None and r['fidelity'] for f in [r['fidelity']['P00']]]
        overall_mean = np.mean(all_fids)

        # Between-group variance
        ssb = sum(len(phase_bins[i]) * (np.mean(phase_bins[i]) - overall_mean)**2
                  for i in range(10) if phase_bins[i])

        # Within-group variance
        ssw = sum(sum((f - np.mean(phase_bins[i]))**2 for f in phase_bins[i])
                  for i in range(10) if phase_bins[i])

        k = sum(1 for i in range(10) if phase_bins[i])  # number of groups with data
        n_total = len(all_fids)

        msb = ssb / (k - 1) if k > 1 else 0
        msw = ssw / (n_total - k) if n_total > k else 0
        f_stat = msb / msw if msw > 0 else 0

        print("\n" + "-"*60)
        print(f"ANOVA: F-statistic = {f_stat:.3f}")
        print(f"SSB (between groups) = {ssb:.6f}")
        print(f"SSW (within groups) = {ssw:.6f}")

        # Backend-specific analysis
        print("\n" + "="*60)
        print("BACKEND-SPECIFIC ANALYSIS")
        print("="*60)

        for backend, backend_results in backends.items():
            backend_aligned = [r['fidelity']['P00'] for r in backend_results
                             if r['tau_phase'] is not None and r['tau_phase'] < 0.5 and r['fidelity']]
            backend_anti = [r['fidelity']['P00'] for r in backend_results
                          if r['tau_phase'] is not None and r['tau_phase'] >= 0.5 and r['fidelity']]

            if backend_aligned and backend_anti:
                b_ratio = np.mean(backend_aligned) / np.mean(backend_anti)
                print(f"\n{backend}:")
                print(f"  Aligned:     N={len(backend_aligned)}, Mean={np.mean(backend_aligned):.4f}")
                print(f"  Anti-aligned: N={len(backend_anti)}, Mean={np.mean(backend_anti):.4f}")
                print(f"  Ratio: {b_ratio:.3f}×")

    # Save results
    output_file = output_dir / 'hardware_analysis_results.json'
    output_data = {
        'analysis_timestamp': datetime.now().isoformat(),
        'total_jobs_analyzed': len(results),
        'backends': {k: len(v) for k, v in backends.items()},
        'tau_phase_statistics': {
            'aligned_mean': float(aligned_mean) if aligned_fidelities else None,
            'aligned_std': float(aligned_std) if aligned_fidelities else None,
            'aligned_n': len(aligned_fidelities),
            'antialigned_mean': float(antialigned_mean) if antialigned_fidelities else None,
            'antialigned_std': float(antialigned_std) if antialigned_fidelities else None,
            'antialigned_n': len(antialigned_fidelities),
            'ratio': float(ratio) if aligned_fidelities and antialigned_fidelities else None,
            't_statistic': float(t_stat) if aligned_fidelities and antialigned_fidelities else None,
            'cohens_d': float(cohens_d) if aligned_fidelities and antialigned_fidelities else None,
            'f_statistic_anova': float(f_stat) if aligned_fidelities and antialigned_fidelities else None
        },
        'bin_statistics': bin_stats if 'bin_stats' in dir() else [],
        'jobs': results
    }

    with open(output_file, 'w') as f:
        json.dump(output_data, f, indent=2, default=str)

    print(f"\n\nResults saved to: {output_file}")

    # Nobel protocol assessment
    print("\n" + "="*60)
    print("NOBEL PROTOCOL v1.1 ASSESSMENT")
    print("="*60)

    criteria = {
        'tau_phase_ratio_significant': ratio > 1.5 if (aligned_fidelities and antialigned_fidelities) else False,
        'cohens_d_large': abs(cohens_d) > 0.8 if (aligned_fidelities and antialigned_fidelities) else False,
        'multiple_backends': len(backends) >= 2,
        'sample_size_adequate': len(results) >= 50,
        'effect_reproducible': all(np.mean([r['fidelity']['P00'] for r in v if r['tau_phase'] and r['tau_phase'] < 0.5 and r['fidelity']]) >
                                  np.mean([r['fidelity']['P00'] for r in v if r['tau_phase'] and r['tau_phase'] >= 0.5 and r['fidelity']])
                                  for v in backends.values() if len(v) > 10)
    }

    print("\nCriteria Assessment:")
    for criterion, met in criteria.items():
        status = "✓ MET" if met else "✗ NOT MET"
        print(f"  {criterion}: {status}")

    criteria_met = sum(criteria.values())
    print(f"\nTotal: {criteria_met}/{len(criteria)} criteria met")

    if criteria_met >= 4:
        print("\n>>> STRONG EVIDENCE FOR τ-PHASE ANOMALY <<<")
        print(">>> PROCEED WITH DISCRIMINATING EXPERIMENT <<<")
    elif criteria_met >= 3:
        print("\n>>> SUGGESTIVE EVIDENCE - REQUIRES FURTHER VALIDATION <<<")
    else:
        print("\n>>> INSUFFICIENT EVIDENCE FROM RETROSPECTIVE DATA <<<")

if __name__ == '__main__':
    main()
